﻿@echo off
chcp 65001 >nul
echo Dang tao Shortcut RMD Remote Desktop ra man hinh Desktop...
powershell -NoProfile -ExecutionPolicy Bypass -Command "$ws = New-Object -ComObject WScript.Shell; $desktop = [Environment]::GetFolderPath('Desktop'); $sc = $ws.CreateShortcut((Join-Path $desktop 'RMD Remote Desktop.lnk')); $sc.TargetPath = (Join-Path $PSScriptRoot 'RMD.exe'); $sc.WorkingDirectory = $PSScriptRoot; if (Test-Path (Join-Path $PSScriptRoot 'icon.ico')) { $sc.IconLocation = (Join-Path $PSScriptRoot 'icon.ico') }; $sc.Description = 'RMD Remote Desktop v1.2.0 PRO'; $sc.Save()"
echo Hoan tat! Shortcut da duoc tao thanh cong tren Desktop.
pause